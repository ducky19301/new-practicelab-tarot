import { db } from "../helpers/db";
import superjson from "superjson";
export async function handle(_request: Request) {
  try {
    const cards = await db.selectFrom("tarotCards").selectAll().where("profileId", "=", "local").orderBy("id").execute();
    return new Response(superjson.stringify({ cards }));
  } catch (error) {
    return new Response(superjson.stringify({ error: error instanceof Error ? error.message : "Unable to load cards" }), { status: 500 });
  }
}
