import { db } from "../helpers/db";
import superjson from "superjson";
export async function handle(_request: Request) {
  try {
    const [progress, practiceCount, journalCount, coachCount] = await Promise.all([
      db.selectFrom("learningProgress").selectAll().where("profileId", "=", "local").orderBy("id").execute(),
      db.selectFrom("practiceSessions").select(({ fn }) => fn.countAll<number>().as("count")).where("profileId", "=", "local").executeTakeFirstOrThrow(),
      db.selectFrom("journalEntries").select(({ fn }) => fn.countAll<number>().as("count")).where("profileId", "=", "local").executeTakeFirstOrThrow(),
      db.selectFrom("coachSessions").select(({ fn }) => fn.countAll<number>().as("count")).where("profileId", "=", "local").executeTakeFirstOrThrow()
    ]);
    return new Response(superjson.stringify({ progress, practiceCount: Number(practiceCount.count), journalCount: Number(journalCount.count), coachCount: Number(coachCount.count) }));
  } catch (error) {
    return new Response(superjson.stringify({ error: error instanceof Error ? error.message : "Unable to load progress" }), { status: 500 });
  }
}
