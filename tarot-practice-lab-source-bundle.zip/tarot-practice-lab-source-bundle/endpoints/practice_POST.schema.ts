import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  cardId: z.number().int().positive().optional(),
  spreadName: z.string().max(200).optional(),
  question: z.string().max(2000).optional(),
  firstImpression: z.string().max(10000).optional(),
  finalInterpretation: z.string().max(10000).optional(),
  readingDate: z.string().regex(/^\\d{4}-\\d{2}-\\d{2}$/).optional(),
  sourceType: z.enum(["new", "imported", "daily", "blind", "physical"]).optional(),
  cards: z.array(z.object({
    cardId: z.number().int().positive(),
    position: z.string().max(100).optional(),
    orientation: z.enum(["upright", "reversed"]).default("upright")
  })).max(15).optional(),
  astrologyContext: z.record(z.string(), z.string().max(200)).optional(),
  numerologyContext: z.record(z.string(), z.string().max(200)).optional(),
  reflection: z.string().max(20000).optional(),
  coach: z.object({
    observe: z.string().max(10000).optional(),
    symbolism: z.string().max(10000).optional(),
    positionContext: z.string().max(10000).optional(),
    intuition: z.string().max(10000).optional(),
    synthesis: z.string().max(10000).optional()
  }).optional(),
  journal: z.object({ title: z.string().max(200).optional(), content: z.string().max(20000) }).optional()
});

export type InputType = z.infer<typeof schema>;
export type OutputType = { id: string; journalId?: string; coachId?: string };

export const postPractice = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const result = await fetch("/_api/practice", {
    method: "POST", body: superjson.stringify(schema.parse(body)), ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) }
  });
  if (!result.ok) throw new Error((await result.text()) || "Unable to save practice");
  return superjson.parse<OutputType>(await result.text());
};
