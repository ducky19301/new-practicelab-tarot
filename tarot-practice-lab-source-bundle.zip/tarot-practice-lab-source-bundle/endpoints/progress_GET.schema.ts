import superjson from "superjson";
import type { Selectable } from "kysely";
import type { LearningProgress } from "../helpers/schema";
export type OutputType = { progress: Selectable<LearningProgress>[]; practiceCount: number; journalCount: number; coachCount: number };
export const getProgress = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch("/_api/progress", { method: "GET", ...init });
  if (!result.ok) throw new Error((await result.text()) || "Unable to load progress");
  return superjson.parse<OutputType>(await result.text());
};
