import superjson from "superjson";

export type JournalReading = {
  id: string;
  readingDate: Date | string | null;
  createdAt: Date | string;
  sourceType: string;
  spreadName: string | null;
  question: string | null;
  firstImpression: string | null;
  finalInterpretation: string | null;
  reflection: string | null;
  journalContent?: string | null;
  readingCards: { cardId: number; position?: string; orientation: "upright" | "reversed" }[];
  astrologyContext: Record<string, string>;
  numerologyContext: Record<string, string>;
};
export type JournalEntry = { id: string; practiceSessionId: string | null; title: string | null; content: string; createdAt: Date | string };
export type OutputType = { readings: JournalReading[]; journal: JournalEntry[] };

export const getJournal = async (init?: RequestInit): Promise<OutputType> => {
  const response = await fetch("/_api/journal", { ...init, headers: { ...(init?.headers ?? {}) } });
  if (!response.ok) throw new Error((await response.text()) || "Unable to load journal");
  return superjson.parse<OutputType>(await response.text());
};
