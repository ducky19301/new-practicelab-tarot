import superjson from "superjson";
import type { Selectable } from "kysely";
import type { TarotCards } from "../helpers/schema";
export type OutputType = { cards: Selectable<TarotCards>[] };
export const getCards = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch("/_api/cards", { method: "GET", ...init });
  if (!result.ok) throw new Error((await result.text()) || "Unable to load cards");
  return superjson.parse<OutputType>(await result.text());
};
