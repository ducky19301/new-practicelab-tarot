import { db } from "../helpers/db";
import superjson from "superjson";

export async function handle(_request: Request) {
  try {
    const readings = await db.selectFrom("practiceSessions").selectAll()
      .where("profileId", "=", "local").orderBy("readingDate", "desc")
      .orderBy("createdAt", "desc").execute();
    const journal = await db.selectFrom("journalEntries").selectAll()
      .where("profileId", "=", "local").orderBy("createdAt", "desc").execute();
    const withJournal = readings.map(reading => ({
      ...reading,
      journalContent: journal.find(entry => entry.practiceSessionId === reading.id)?.content ?? null
    }));
    return new Response(superjson.stringify({ readings: withJournal, journal }));
  } catch (error) {
    return new Response(superjson.stringify({ error: error instanceof Error ? error.message : "Unable to load journal" }), { status: 500 });
  }
}
