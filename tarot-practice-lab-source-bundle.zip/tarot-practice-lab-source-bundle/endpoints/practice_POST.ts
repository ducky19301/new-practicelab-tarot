import { db } from "../helpers/db";
import { schema } from "./practice_POST.schema";
import superjson from "superjson";
import { nanoid } from "nanoid";

export async function handle(request: Request) {
  try {
    const input = schema.parse(superjson.parse(await request.text()));
    const id = nanoid();
    const readingCards = input.cards ?? (input.cardId ? [{ cardId: input.cardId, position: "Card 1", orientation: "upright" as const }] : []);
    await db.insertInto("practiceSessions").values({
      id, profileId: "local", cardId: input.cardId ?? readingCards[0]?.cardId ?? null,
      spreadName: input.spreadName ?? null, question: input.question ?? null,
      firstImpression: input.firstImpression ?? null, finalInterpretation: input.finalInterpretation ?? null,
      readingDate: input.readingDate ? new Date(input.readingDate + "T12:00:00") : new Date(),
      sourceType: input.sourceType ?? "new", readingCards: readingCards as never,
      astrologyContext: (input.astrologyContext ?? {}) as never,
      numerologyContext: (input.numerologyContext ?? {}) as never,
      reflection: input.reflection ?? null
    }).execute();

    let coachId: string | undefined;
    if (input.coach) {
      coachId = nanoid();
      await db.insertInto("coachSessions").values({
        id: coachId, profileId: "local", practiceSessionId: id, cardId: input.cardId ?? null,
        observe: input.coach.observe ?? null, symbolism: input.coach.symbolism ?? null,
        positionContext: input.coach.positionContext ?? null, intuition: input.coach.intuition ?? null,
        synthesis: input.coach.synthesis ?? null, completedAt: new Date()
      }).execute();
    }

    let journalId: string | undefined;
    if (input.journal || input.reflection) {
      journalId = nanoid();
      await db.insertInto("journalEntries").values({
        id: journalId, profileId: "local", practiceSessionId: id,
        title: input.journal?.title ?? input.spreadName ?? "Reading reflection",
        content: input.journal?.content ?? input.reflection ?? ""
      }).execute();
    }
    return new Response(superjson.stringify({ id, journalId, coachId }));
  } catch (error) {
    return new Response(superjson.stringify({ error: error instanceof Error ? error.message : "Unable to save practice" }), { status: 400 });
  }
}
