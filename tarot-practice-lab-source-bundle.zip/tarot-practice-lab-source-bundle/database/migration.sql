ALTER TABLE practice_sessions
  ADD COLUMN IF NOT EXISTS reading_date date,
  ADD COLUMN IF NOT EXISTS source_type text NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS reading_cards jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS astrology_context jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS numerology_context jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS reflection text;

UPDATE practice_sessions SET reading_date = created_at WHERE reading_date IS NULL;
