import { schema } from "../endpoints/practice_POST.schema";

describe("practice reading import schema", () => {
  it("preserves original date, source, card positions, and astrology/numerology context", () => {
    const input = {
      spreadName: "Past Celtic Cross",
      readingDate: "2026-03-12",
      sourceType: "imported",
      cards: [
        { cardId: 18, position: "Present", orientation: "upright" },
        { cardId: 16, position: "Challenge", orientation: "reversed" }
      ],
      astrologyContext: { sun: "Pisces", moon: "Aquarius", rising: "Libra" },
      numerologyContext: { lifePath: "9", personalYear: "3" },
      reflection: "A reading I want to revisit."
    };
    const parsed = schema.parse(input);
    expect(parsed.readingDate).toBe("2026-03-12");
    expect(parsed.sourceType).toBe("imported");
    expect(parsed.cards?.length).toBe(2);
    expect(parsed.cards?.[1].orientation).toBe("reversed");
    expect(parsed.astrologyContext?.sun).toBe("Pisces");
    expect(parsed.numerologyContext?.lifePath).toBe("9");
    expect(parsed.reflection).toBe("A reading I want to revisit.");
  });
});
