# Tarot Practice Lab — source bundle

This is a focused source bundle for the recent Reading Journal / Daily Readings feature update.

## Included
- Reading import and practice-save API endpoint
- Journal history API endpoint and client schema
- Tarot card and learning-progress API endpoints
- Database type schema and database helper
- Import schema test
- A CSS patch with the card-thumbnail zoom correction and journal layout additions
- Project dependency manifest

## Important
This is **not a complete standalone export of the Floot project**. Floot's seeded component library, project runtime/configuration, database contents, uploaded assets, and the complete page source remain in the original Floot project. The app's current source of truth is still the Floot project.

Project: Tarot Practice Lab
Floot project ID: `1775783b-37fc-4b31-b50d-6b3fc579ce89`

Preview: https://floot.com/mcp-preview/1775783b-37fc-4b31-b50d-6b3fc579ce89

## Before running elsewhere
1. Create a React + TypeScript project.
2. Install the dependencies listed in `package.json`.
3. Add Floot's shared UI components or replace imports with your own components.
4. Configure a PostgreSQL database and set `FLOOT_DATABASE_URL`.
5. Apply the schema changes already made in the Floot database.
6. Copy the app page and styles from the original Floot project. They are not duplicated here because Floot's project export surface does not provide a complete source archive.
